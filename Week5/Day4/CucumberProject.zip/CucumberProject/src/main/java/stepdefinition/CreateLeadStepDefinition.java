package stepdefinition;

import org.openqa.selenium.By;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateLeadStepDefinition extends BaseClass {
	

@When("Click the CRMSFA button")
public void click_the_crmsfa_button() {
	driver.findElement(By.linkText("CRM/SFA")).click();
}
@When("Click the Leads button")
public void click_the_leads_button() {
	driver.findElement(By.linkText("Leads")).click();
}
@When("Click the CreateLead button")
public void click_the_create_lead_button() {
	driver.findElement(By.linkText("Create Lead")).click();
}
@When("Enter the companyname as {string}")
public void enter_the_companyname(String companyName) {
	driver.findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
}
@When("Enter the firstname as {string}")
public void enter_the_first_name(String firstName) {
	driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
}
@When("Enter the lastname as {string}")
public void enter_the_last_name(String lastName) {
	driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
}
@When("Click on the CreateLead Submit button")
public void click_on_the_create_lead_submit_button() {
	driver.findElement(By.name("submitButton")).click();
}
@Then("Lead should be created")
public void lead_should_be_created() {
 String firstName = driver.findElement(By.id("viewLead_firstName_sp")).getText();
 System.out.println(firstName);
 if (firstName.contains("Vineeth")) {
	System.out.println("Lead is created");
}
 else {
	System.out.println("Lead is not created");
}
}

}
