package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class CreateLeadPage extends BaseClass {
	
	public CreateLeadPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public CreateLeadPage enterCompanyname() {
		// TODO Auto-generated method stub
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("TestLeaf");
	    return this;
	}
	
	public CreateLeadPage enterFirstname() {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Vineeth");
        return this;
	}
	
	public CreateLeadPage enterlastName() {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("Rajendran");
	return this;
	}
	
	
	public ViewLeadPage clickCreateLeadbutton() {
		 driver.findElement(By.name("submitButton")).click();
         return new ViewLeadPage(driver);
	}

}
