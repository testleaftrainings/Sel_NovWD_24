package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends BaseClass {
	
	
	
	@Then("It should navigate to the next page")
	public void verifyLogin() {
		// TODO Auto-generated method stub
System.out.println("Login is verified");
	}
	
	@When("It throws error message")
	public void it_throws_error_message() {
	   System.out.println("It Throws error message");
	}

	@When("Click the CRMSFA button")
	public MyHomePage clickCrmsfaLink() {
		driver.findElement(By.linkText("CRM/SFA")).click();
        return new MyHomePage();
	}
	
	
}
