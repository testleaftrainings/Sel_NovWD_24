package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;

public class ViewLeadPage extends BaseClass {
	
	
	
	@And("Lead should be created")
	public void validateLead() {
	System.out.println("Lead is created");

	}
}
