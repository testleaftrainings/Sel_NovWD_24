package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {
	//public static ChromeDriver driver;
	
	//Object reference-1
	
	//driver=new ChromeDriver();
	
	//Browser1 - 001
	//Browser2 - 002
	
	public String fileName;
	//ThreadLocal
	private static final ThreadLocal<ChromeDriver> cDriver=new ThreadLocal<ChromeDriver>();
	
	//Get & Set
	
	public void setterDriver() {
		cDriver.set(new ChromeDriver());

	}
	//
	public ChromeDriver getDriver() {
		
    return cDriver.get();
	}
	
	
	
	
	@BeforeMethod
	public void preConditions() {
		setterDriver();    //driver=new ChromeDriver
		getDriver().get("http://leaftaps.com/opentaps");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

	}
	
	@AfterMethod
	public void postConditions() {
		getDriver().close();

	}
	@DataProvider
	public String[][] sendData() throws IOException {
	return ReadExcel.readData(fileName);

	}

}
