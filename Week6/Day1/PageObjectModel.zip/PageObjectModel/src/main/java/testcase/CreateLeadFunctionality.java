package testcase;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class CreateLeadFunctionality extends BaseClass {
	
	@Test
	public void runCreateLead() {
	 LoginPage lp=new LoginPage();
	 lp.enterUsername()
	 .enterPassword()
	 .clickLoginButton()
	 .clickCrmsfaLink()
	 .clickLeads()
	 .clickCreateLeads()
	 .enterCompanyname()
	 .enterFirstname()
	 .enterlastName()
	 .clickCreateLeadbutton()
	 .validateLead();

	}

}
