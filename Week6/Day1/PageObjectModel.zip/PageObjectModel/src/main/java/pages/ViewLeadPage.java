package pages;

import base.BaseClass;

public class ViewLeadPage extends BaseClass {
	public void validateLead() {
	System.out.println("Lead is created");

	}
}
