package week3.day2;

public class LearnInheritance2 extends LearnInheritance1 {
	
	//LearnInheritance2 - ChildClass/DerivedClass
	//LearnInheritance1 - ParentClass/SuperClass
	

	public static void main(String[] args) {
		LearnInheritance2 inher=new LearnInheritance2();
		inher.method1();

	}

}
