package week3.day2;

public class LearnInheritance1 {
	
	public void method1() {
		System.out.println("Method 1 executed");

	}
	

	public static void main(String[] args) {
		LearnInheritance1 inher=new LearnInheritance1();

	}

}
