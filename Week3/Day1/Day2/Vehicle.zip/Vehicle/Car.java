package week3.day2;

public class Car extends Vehicle {
	
	public void fourWheeler() {
		System.out.println("Four Wheeler");

	}
	
	

	public static void main(String[] args) {
	Car carProperties=new Car();
	carProperties.ApplyBrake();
	carProperties.ApplyAccelerate();
	carProperties.ApplyHorn();
	carProperties.fourWheeler();
	

	}

}
