package week3.day2;

public class Vehicle {
	
	public void ApplyBrake() {
		System.out.println("ApplyBrake");

	}
	
	public void ApplyAccelerate() {
		System.out.println("ApplyAccelerate");
		

	}
	
	public void ApplyHorn() {
		System.out.println("ApplyHorn");

	}

}
