package week3.day2;

public class Auto extends Vehicle {
	
	public void threeWheeler() {
		System.out.println("3 Wheeler");

	}
	
	public static void main(String[] args) {
		Auto autoProperties =new Auto();
		autoProperties.ApplyAccelerate();
		autoProperties.ApplyBrake();
		autoProperties.ApplyHorn();
		autoProperties.threeWheeler();
		

	}

}
