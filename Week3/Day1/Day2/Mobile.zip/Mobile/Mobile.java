package week3.day2;

public class Mobile {
	
  public void makeCall() {
	System.out.println("Make call");

}
	

}
