package week3.day2;

public class AndroidMobile {
	
	public void androidVersion() {
		System.out.println("12");

	}
	
	public void makeCall() {
		System.out.println("Make call");

	}
	
	public static void main(String[] args) {
		AndroidMobile andr=new AndroidMobile();
		andr.androidVersion();
		andr.makeCall();
		
	}

}
