package week3.day2;

public class AndroidLatestVersion extends AndroidMobile{
	
	//AndroidLatestVersion extends AndroidMobile
	//  Child                         Parent
	//AndroidMobile extends Mobile
	//Child                   Parent
	//AndroidLatestVersion extends AndroidMobile extends Mobile
	
	public void latestVersion() {
	System.out.println("15");

	}

	public static void main(String[] args) {
		AndroidLatestVersion version=new AndroidLatestVersion();
        version.latestVersion();
        version.androidVersion();
        version.makeCall();
	}

}
