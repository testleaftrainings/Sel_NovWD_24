package com.leaftaps.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage enterUsername(String uName) {

		clearAndType(locateElement("username"), uName);
         return this;
	}
	
	
	public LoginPage enterPassword(String pWord) {
		clearAndType(locateElement(Locators.ID, "password"), pWord);
        return this;
	}
	
	public void clickLoginButton() {
		click(locateElement("Login"));
       
	}

}
