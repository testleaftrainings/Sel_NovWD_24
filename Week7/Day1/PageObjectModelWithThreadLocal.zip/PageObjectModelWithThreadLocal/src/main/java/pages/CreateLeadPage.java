package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class CreateLeadPage extends BaseClass {
	
	
	@When("Enter the companyname as {string}")
	public CreateLeadPage enterCompanyname(String cName) {
		// TODO Auto-generated method stub
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
	    return this;
	}
	@And("Enter the firstname as {string}")
	public CreateLeadPage enterFirstname(String fName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
        return this;
	}
	@And("Enter the lastname as {string}")
	public CreateLeadPage enterlastName(String lName) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
	return this;
	}
	
	@And("Click on the CreateLead Submit button")
	public ViewLeadPage clickCreateLeadbutton() {
		 getDriver().findElement(By.name("submitButton")).click();
         return new ViewLeadPage();
	}

}
